In this section you will find some image processing methods that cover aspects such as convolution, 
some filters of the spatial domain and some others of the frequency domain, these being of the low-pass type.
